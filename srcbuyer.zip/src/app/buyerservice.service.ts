import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Buyermodel, Cart, ViewCart } from './buyer';
import { ApiResponse } from './api.response';
import { SearchItem } from './search';
import { Stock } from './item';

@Injectable({
  providedIn: 'root'
})
export class BuyerserviceService {

  constructor(private http : HttpClient) { }

  getItemList():Observable<any> {
    return this.http.get(`http://localhost:8080/item/getAll`);
  }

  createBuyer(buyer: Buyermodel):Observable<Object> {
    return this.http.post(`http://localhost:8081/buyer/signup`,buyer);
  }

  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8081/' + 'token/generate-token', loginPayload);
  }

  addToCart(cart:Cart):Observable<any> {
    return this.http.post(`http://localhost:8081/cart/addcartitem/1`,cart);
  }

  deleteCart(cartId: number):Observable<any>{
    //console.log(cartId);
    return this.http.delete(`http://localhost:8081/cart/deletecartitembyid/${cartId}`);
  }

  updateCart(cartView:ViewCart):Observable<any>{
    return this.http.put(`http://localhost:8081/cart/update`,cartView);
  }

  viewCart():Observable<any>{
    return this.http.get(`http://localhost:8081/cart/getAll/1`);
  }

  getCustomersByString(searchStr: string):Observable<any>{
    let searchItem = new SearchItem(searchStr);
    return this.http.post(`http://localhost:8080/item/searchitem`,searchItem);
  }

  checkoutCart():Observable<any>{
    return this.http.get(`http://localhost:8081/cart/checkout/1`);
  }

  updateStock(stock:Stock[]):Observable<any>{
    return this.http.put(`http://localhost:8080/item/updatestock`,stock);
  }
  

}
