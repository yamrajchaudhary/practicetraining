export class SearchItem {
    //searchString : string;
    constructor( private searchString:string ){
        
    }
}