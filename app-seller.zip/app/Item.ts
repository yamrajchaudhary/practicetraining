export class Itemsearch1
{
searchString:String;
}