import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
//import { info } from '../seller';
@Injectable({
  providedIn: 'root'
})
export class SellerserviceService {

  private baseUrl = 'http://localhost:8080/sellers/add';

  constructor(private http: HttpClient) { }


  addsell(info:Object):Observable<any>
  {   
      console.log("in sevie method");
      console.log(info);
      
      return this.http.post(`${this.baseUrl}`,info);
  }
}
