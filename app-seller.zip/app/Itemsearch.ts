export class Itemlist
{   
    itemsId:number;
    itemsName:String;
    price:number;
    stock:number;
    description:String;
    remark:String;
    quantity:number;
    }













  