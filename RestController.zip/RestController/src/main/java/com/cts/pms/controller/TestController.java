package com.cts.pms.controller;
import java.util.*;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
	List<Product> li= new ArrayList();
	HashMap<Integer,Product> hm =new HashMap();
	public TestController() {
	/*	li.add(new Product("tv",500,5));
		li.add(new Product("ac",600,6));
		li.add(new Product("car",800,1));*/
		
		hm.put(101,new Product("tv",500,5));
		hm.put(102,new Product("ac",600,6));
		hm.put(103,new Product("car",800,1));
		
	}
	
	
	
	@RequestMapping("/data")
	public List<Product> m1()
	{
		return li;
	}
	
	@RequestMapping("jsondata/")
	public HashMap<Integer,Product> m2()
	{
		return hm;
	}

	@RequestMapping(value ="jsondata/{pid}/", method =RequestMethod.GET)
	public Product search(@PathVariable("pid") int id)
	{
		return hm.get(id) ;	
	}
}
