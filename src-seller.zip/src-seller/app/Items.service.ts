import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Itemsearch1 } from './Item';
import { ApiResponse } from './api.response';

@Injectable({
    providedIn: 'root'
  })
  export class Itemservice 
  {
 
    private baseUrl = 'http://localhost:8082/seller/search';
    private baseUrl1 = 'http://localhost:8082/Add/items/1';
    private baseurl2 = 'http://localhost:8080/sellers/1/additems';
    private baseurl3 = 'http://localhost:8080/sellers/1/7/deleteitems';
    private baseurl4 = 'http://localhost:8080/sellers/3/updateitems';
    private baseurl5 = 'http://localhost:8080/sellers/searchitem';
    private baseurl6 = 'http://localhost:8081/2/addcartitems';
    private baseurl7 = 'http://localhost:8081/2/searchAllitem';
   private baseurl = 'http://localhost:8080/token/generate-token'
    constructor(private http: HttpClient) { }
    //seller
    getItemByName(Itemsearch1:Object):Observable<any>
    {   
        console.log("in sevie method");
        console.log(Itemsearch1);
        
        return this.http.post(`${this.baseurl5}`,Itemsearch1);
    }
    additems(Itemlist:object):Observable<any> 
    { 
      console.log(Itemlist);
      console.log("in sevie method");
      return this.http.post(`${this.baseurl2}`,Itemlist);
    }


    //buyer
    addcartitem(cartitems:object):Observable<any>
    {
      console.log(cartitems);
      return this.http.post(`${this.baseurl6}`,cartitems);
    }
   
   
   //buyer
    getallItems():Observable<any>
    {
      console.log("In Service");
      return this.http.get(`${this.baseurl7}`);
    }
    //seller
deleteitem(Itemsid:number):Observable<any>
{
console.log("enter to delete");
return this.http.delete(`${this.baseurl3}`);


}
//seller
updateitems(Itemlist:object):Observable<any>
{

  console.log("Itemlist");
  console.log("in sevice");

  return this.http.put(`${this.baseurl4}`,Itemlist);

}

login(loginPayload:object):Observable<ApiResponse>{

  return this.http.post<ApiResponse>(`${this.baseurl}`,loginPayload);
  }




  }