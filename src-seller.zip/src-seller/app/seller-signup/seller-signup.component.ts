import { Component, OnInit, Input } from '@angular/core';
import {SellerserviceService} from '../sellerservice.service';
import { info } from './sellerinfo';
@Component({
  selector: 'app-seller-signup',
  templateUrl: './seller-signup.component.html',
  styleUrls: ['./seller-signup.component.css']
})
export class SellerSignupComponent implements OnInit {
  username:String;
  password:String;
  companyName:String;
  gstIn:String;
  infoAboutCompany:String;
  postalAddress:String;
  website:String;
  email:String;
  contactNumber:number;
@Input() items : info = new info();

  constructor(private dataService:SellerserviceService) { }

  ngOnInit(): void {
  }

  addseller(){
    console.log("enter into addsellermethod");
    this.items.username=this.username;
    this.items.password=this.password;
    
    this.items.companyName=this.companyName;
    
    this.items.gstIn=this.gstIn;
    this.items.infoAboutCompany=this.infoAboutCompany;

    this.items.postalAddress=this.postalAddress;
    this.items.website=this.website;
    
    this.items.email=this.email;
    
    this.items.contactNumber=this.contactNumber;
    





    this.dataService.addsell(this.items).subscribe( info => this.items = info);
  }

  }




