import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {Itemservice} from './Items.service';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { AdditemsComponent } from './additems/additems.component';
import { SellerSignupComponent } from './seller-signup/seller-signup.component';
import { LoginSellerComponent } from './login-seller/login-seller.component';



//import { Itemsearch1 } from './Item';
//import {Itemlist} from './Itemsearch';

@NgModule({
  declarations: [
    AppComponent,
    ItemDetailsComponent,
    AdditemsComponent,
    SellerSignupComponent,
    LoginSellerComponent,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
   // Itemservice,
   //Itemsearch1,
    //Itemlist,
    HttpClientModule
  ],
  providers: [Itemservice],
  bootstrap: [AppComponent]
})
export class AppModule { }
