import { Component, OnInit } from '@angular/core';
import { Itemservice } from '../Items.service';
import { Itemlist } from '../Itemsearch';

@Component({
  selector: 'app-additems',
  templateUrl: './additems.component.html',
  styleUrls: ['./additems.component.css']
})
export class AdditemsComponent implements OnInit {

  deleteitems:number;
  itemsName:String;
  price:number;
  remark:String;
  description:String;
  stock:number;
  items:Itemlist = new Itemlist();
  constructor(private dataService: Itemservice){}

  ngOnInit(): void {
  } 
  additems() 
  {
    this.items.itemsName=this.itemsName;
    this.items.stock=this.stock;
    
    this.items.price=this.price;
    
    this.items.description=this.description;
    this.items.remark=this.remark;
    this.dataService.additems(this.items).subscribe( item => this.items = item);
  }
deleteitem()
  {
    console.log("in .ts");
    this.dataService.deleteitem(this.deleteitems).subscribe(Itemlist=>this.items=this.items);
  }
updateitem()
{
  console.log("in update");
  this.items.itemsName=this.itemsName;
  this.items.stock=this.stock;
  
  this.items.price=this.price;
  
  this.items.description=this.description;
  this.items.remark=this.remark;
  this.dataService.updateitems(this.items).subscribe( Itemlist => this.items = Itemlist)
}



}
