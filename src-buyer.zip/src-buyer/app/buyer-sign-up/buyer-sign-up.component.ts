import { Component, OnInit, Input } from '@angular/core';
import { BuyerServiceService } from '../buyer-service.service';
import { buyersignup } from '../buyersignup';


@Component({
  selector: 'app-buyer-sign-up',
  templateUrl: './buyer-sign-up.component.html',
  styleUrls: ['./buyer-sign-up.component.css']
})
export class BuyerSignUpComponent implements OnInit {
  buyerName:String;
  password:String;
  buyerEmail:String;
  mobileNumber:number;
@Input() items:buyersignup = new buyersignup();
  constructor(private dataservice:BuyerServiceService) { }

  ngOnInit(): void {
  }
  buyersignup(){
    console.log("enter into addsellermethod");
    this.items.password=this.password;
    
    this.items.buyerName=this.buyerName;
    
    this.items.buyerEmail=this.buyerEmail;
    this.items.mobileNumber=this.mobileNumber;

    this.dataservice.buyerssignup(this.items).subscribe( buyersignup => this.items = buyersignup);
  }

}
