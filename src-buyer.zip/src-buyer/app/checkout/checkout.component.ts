import { Component, OnInit } from '@angular/core';
import { BuyerServiceService } from '../buyer-service.service';
import { transactions } from '../transaction';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  transactionType:String;
  remark:String;
  transaction: transactions;
  ids:number;
  constructor(private dataService: BuyerServiceService) { }

  ngOnInit(): void {
  }
  checkout()
  {
    console.log("in checkout.ts")
    this.transaction = new transactions();
   
    this.transaction.remark=this.remark;
    this.transaction.transactionType=this.transactionType;
    this.ids=3;
    this.dataService.checkouttransac(this.ids,this.transaction).subscribe(transactions=>this.transaction=transactions);
  }

}
