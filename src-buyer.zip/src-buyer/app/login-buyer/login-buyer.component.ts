import { Component, OnInit } from '@angular/core';
import { BuyerServiceService } from '../buyer-service.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login-buyer',
  templateUrl: './login-buyer.component.html',
  styleUrls: ['./login-buyer.component.css']
})
export class LoginBuyerComponent implements OnInit {

 
  loginForm: FormGroup;
  invalidLogin: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router, private apiService:BuyerServiceService ) { }
  ngOnInit(): void {

    window.localStorage.removeItem('token');
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required]],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.loginForm.invalid) {
      return;
    }
    
    const loginPayload = {
      username: this.loginForm.controls.username.value,
      password: this.loginForm.controls.password.value
    }
    this.apiService.login(loginPayload).subscribe(data => {
      //debugger;
      
      if(data.result.token !== null) {
        window.localStorage.setItem('token', data.result.token);
        window.localStorage.setItem('buyerName', data.result.username);
        window.localStorage.setItem('buyerId', data.result.buyerId);
        this.router.navigate(['additems']);
        
      }else {
        this.invalidLogin = true;
        alert(data.message);
      }
    });
  }

}
