import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiResponse } from 'api.response';

@Injectable({
  providedIn: 'root'
})
export class BuyerServiceService {
  private baseUrl1 = 'http://localhost:8081/addbuyer';
  private baseurl7 = 'http://localhost:8081/1/searchAllitem'; //seller
  private baseurl6 = 'http://localhost:8081/2/addcartitems'; //buyer
  private baseurl8 = 'http://localhost:8081';//buyer
  private baseurl9 = 'http://localhost:8080/token/generate-token';
  constructor(private http: HttpClient) { }
  buyerssignup(buyersignup:Object):Observable<any>
  {   
      console.log("in buyer method");
      console.log(buyersignup);
      
      return this.http.post(`${this.baseUrl1}`,buyersignup);
  }
  login(loginPayload:object):Observable<ApiResponse>{

  return this.http.post<ApiResponse>(`${this.baseurl9}`,loginPayload);
  }
  //buyer
  getallItems():Observable<any>
  {
    console.log("In Service");
    return this.http.get(`${this.baseurl7}`);
  }
  addcartitem(cartitems:object):Observable<any>
  {
    console.log(cartitems);
    return this.http.post(`${this.baseurl6}`,cartitems);
  }
  updatecartitems(cartitems:object,cartitemid:number):Observable<any>
  {
    console.log(cartitems);
    return this.http.put(`${this.baseurl8}/${cartitemid}/update`,cartitems);
  }
 
  deleteCartItems(cartitemid:number):Observable<any>
  {
    
    return this.http.delete(`${this.baseurl8}/${cartitemid}/delete`);
  }
  checkouttransac(ids:number,transactions:object):Observable<any>
  {
    
    return this.http.post(`${this.baseurl8}/checkout/${ids}`,transactions);
  }
 


}
