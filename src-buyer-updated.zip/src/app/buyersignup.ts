
export class buyersignup {

    buyerName:String;
    password:String;
    buyerEmail:String;
    mobileNumber:number;





}














