import { Component, OnInit, Input } from '@angular/core';
import { Itemlist } from '../Itemsearch';
import {cartitems} from '../cartitem';
import { BuyerServiceService } from '../buyer-service.service';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css']
})
export class ItemDetailsComponent implements OnInit {
  cartitem:cartitems;
 // constructor(private dataService: BuyerServiceService){}
 @Input() items:Itemlist = new Itemlist();
 
 // ngOnInit(): void {
  //}
  
 //addCart() 
  //{
   // this.cartitem = new cartitems();
   // this.cartitem.itemId = this.items.itemsId;
    //this.cartitem.cartItemId=6;
    //this.cartitem.price=this.items.price;
   // this.cartitem.quantity=1;
   // this.dataService.addcartitem(this.cartitem).subscribe(cartitems=>this.cartitem=cartitems);

  //}
 // @Input() Itemlist: Itemlist;
  
  abc:any;
  cartitems: any;
  constructor(private buyerService : BuyerServiceService) { }

  ngOnInit(): void {
  }

  onSave(itemsId:number,unitPrice:number){
    
    //console.log("aaaaaaaaaaaaaaaa");
    let cart:cartitems = new this.cartitems();
    this.cartitem = new cartitems();
    this.cartitem.itemId = this.items.itemsId;
    this.cartitem.cartItemId=6;
    this.cartitem.price=this.items.price;
    this.cartitem.quantity=1;
   this.buyerService.addcartitem(this.cartitem).subscribe(cartitems=>this.cartitem=cartitems);
    
  }

}

