import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BuyerSignUpComponent } from './buyer-sign-up/buyer-sign-up.component';
import { LoginBuyerComponent } from './login-buyer/login-buyer.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { GetAllItemsComponent } from './get-all-items/get-all-items.component';
import { ItemDetailsComponent } from './item-details/item-details.component';


const routes: Routes = [
  {path:'buyerSignUp',component: BuyerSignUpComponent},
  {path:'loginBuyer',component:LoginBuyerComponent},
  {path:'checkout',component:CheckoutComponent},
  {path:'getAllItems',component:GetAllItemsComponent},
  {path:'AddItem',component:ItemDetailsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
