package com.egg.model;

public class AuthToken {

    private String token;
    private String username;
private Integer sellersId;
    public AuthToken(){

    }

    public AuthToken(String token, String username,Integer sellersId){
        this.token = token;
        this.username = username;
        this.sellersId=sellersId;
    }

    public AuthToken(String token){
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

	public Integer getSellersId() {
		return sellersId;
	}

	public void setSellersId(Integer sellersId) {
		this.sellersId = sellersId;
	}
    
}
