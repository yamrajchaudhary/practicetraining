package com.egg.model;

public class SearchItems {
	private String searchString;
	//private String manufacturer;
	//private Double fromPrice;
	//private Double toPrice;
	
	public SearchItems() {
		// TODO Auto-generated constructor stub
	}
	
	
	public SearchItems(String searchString) {
		
		this.searchString = searchString;
	}


	public String getSearchString() {
		return searchString;
	}
	
	public void setSearchString(String searchString) {
		this.searchString = searchString;
	}

}
