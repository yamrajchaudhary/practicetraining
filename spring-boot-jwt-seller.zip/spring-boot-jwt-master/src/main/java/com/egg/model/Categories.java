package com.egg.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Categories implements Serializable {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer categoriesId;
	private String categoriesName;
	private String briefInfo;
	public Categories() {
		
		
	}
	public Integer getCategoriesId() {
		return categoriesId;
	}
	public void setCategoriesId(Integer categoriesId) {
		this.categoriesId = categoriesId;
	}
	public String getCategoriesName() {
		return categoriesName;
	}
	public void setCategoriesName(String categoriesName) {
		this.categoriesName = categoriesName;
	}
	public String getBriefInfo() {
		return briefInfo;
	}
	public void setBriefInfo(String briefInfo) {
		this.briefInfo = briefInfo;
	}
	public Categories(Integer categoriesId, String categoriesName, String briefInfo) {
		super();
		this.categoriesId = categoriesId;
		this.categoriesName = categoriesName;
		this.briefInfo = briefInfo;
	}
	@Override
	public String toString() {
		return "Categories [categoriesId=" + categoriesId + ", categoriesName=" + categoriesName + ", briefInfo="
				+ briefInfo + "]";
	}
	
	
	

}
