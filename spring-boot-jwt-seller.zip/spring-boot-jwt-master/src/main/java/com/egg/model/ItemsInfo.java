package com.egg.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class ItemsInfo implements Serializable {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer itemsId;
	private String itemsName;
	@ManyToOne
	@JoinColumn(name = "sellersId")
	private Sellers sellers;
	@ManyToOne
	@JoinColumn(name = "categoriesId")
	private Categories categoriesId;
	@ManyToOne
	@JoinColumn(name = "subCategoriesId")
	private SubCategories subCategoriesId;
	private Double price;
	private Integer stock;
	private String description;
	private String remark;
	public ItemsInfo() {
		
	}
	public ItemsInfo(Integer itemsId, String itemsName, Sellers sellers, Categories categoriesId,
			SubCategories subCategoriesId, Double price, Integer stock, String description, String remark) {
		super();
		this.itemsId = itemsId;
		this.itemsName = itemsName;
		this.sellers = sellers;
		this.categoriesId = categoriesId;
		this.subCategoriesId = subCategoriesId;
		this.price = price;
		this.stock = stock;
		this.description = description;
		this.remark = remark;
	}
	public Integer getItemsId() {
		return itemsId;
	}
	public void setItemsId(Integer itemsId) {
		this.itemsId = itemsId;
	}
	public String getItemsName() {
		return itemsName;
	}
	public void setItemsName(String itemsName) {
		this.itemsName = itemsName;
	}
	public Sellers getSellers() {
		return sellers;
	}
	public void setSellers(Sellers sellers) {
		this.sellers = sellers;
	}
	public Categories getCategoriesId() {
		return categoriesId;
	}
	public void setCategoriesId(Categories categoriesId) {
		this.categoriesId = categoriesId;
	}
	public SubCategories getSubCategoriesId() {
		return subCategoriesId;
	}
	public void setSubCategoriesId(SubCategories subCategoriesId) {
		this.subCategoriesId = subCategoriesId;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Integer getStock() {
		return stock;
	}
	public void setStock(Integer stock) {
		this.stock = stock;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "ItemsInfo [itemsId=" + itemsId + ", itemsName=" + itemsName + ", sellers=" + sellers + ", categoriesId="
				+ categoriesId + ", subCategoriesId=" + subCategoriesId + ", price=" + price + ", stock=" + stock
				+ ", description=" + description + ", remark=" + remark + "]";
	}
	
	
	
	
	
	
	
	
	

}
