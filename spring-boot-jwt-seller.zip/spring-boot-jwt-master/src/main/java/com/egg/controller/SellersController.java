package com.egg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.ItemsInfo;
import com.egg.model.SearchItems;
import com.egg.model.Sellers;
import com.egg.service.ItemsInfoService;
import com.egg.service.SellersService;





@CrossOrigin(origins="*")
@RestController
@RequestMapping("/sellers")
public class SellersController {
	
	@Autowired
	private SellersService sellersService;
	
	@Autowired
	private ItemsInfoService itemsInfo;
	
	@PostMapping(value = "/add", produces = "application/json")
	public Sellers addSellersInfo(@RequestBody Sellers sellers) {
		Sellers s = sellersService.addSellers(sellers);
		return s;
		
	}
	@PostMapping(value="/{sid}/additems",produces = "application/json")
	public ItemsInfo addItem(@PathVariable("sid") Integer sellersId,@RequestBody ItemsInfo items) {
		Optional<ItemsInfo> savedItem = itemsInfo.addItem(items, sellersId);
		System.out.println(items);
		return savedItem.get();
	}
	@GetMapping(value = "/{sellersid}/getAll")
	public List<ItemsInfo> getAllItems(@PathVariable("sellersid") Integer sellersId) {
		return itemsInfo.getAllItems(sellersId);
	}
	
	@PutMapping(value = "/{itemid}/updateitems", produces = "application/json")
	public ItemsInfo modifyItem(@RequestBody ItemsInfo item, @PathVariable("itemid") Integer itemsId) {
		return itemsInfo.modifyItem(item, itemsId);
	}
	
	@DeleteMapping(value = "/{sellersid}/{itemid}/deleteitems")
	public void removeItem(@PathVariable("sellersid") Integer sellersId, @PathVariable("itemid") Integer itemsId) {
		itemsInfo.removeItem(sellersId, itemsId);
	}

	@PostMapping(value = "/searchitem", produces = "application/json")
	public List<ItemsInfo> searchItems(@RequestBody SearchItems items) {
		System.out.println(items);
		return itemsInfo.searchItem(items);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
