package com.egg.service;

import java.util.Arrays;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.ItemsInfoRepository;
import com.egg.dao.SellersRepository;

import com.egg.model.Sellers;



@Service(value = "userService")
public class SellersService implements UserDetailsService {

@Autowired
private SellersRepository sellersRepo;
@Autowired
private ItemsInfoRepository info;
@Autowired
private BCryptPasswordEncoder bcryptEncoder;

public Sellers addSellers( Sellers sellers) {
	sellers.setPassword(bcryptEncoder.encode(sellers.getPassword()));

	return sellersRepo.save(sellers);

}	
@Override
public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	Sellers user = sellersRepo.findByusername(username);
	if(user == null){
		throw new UsernameNotFoundException("Invalid username or password.");
	}
	return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), getAuthority());
}

private List<SimpleGrantedAuthority> getAuthority() {
	return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
}

public Sellers findOne(String username) {
	return sellersRepo.findByusername(username); 
}

}
