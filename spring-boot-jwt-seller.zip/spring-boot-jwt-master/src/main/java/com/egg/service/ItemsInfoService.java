package com.egg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.ItemsInfoRepository;
import com.egg.dao.SellersRepository;
import com.egg.model.ItemsInfo;
import com.egg.model.SearchItems;




@Service
public class ItemsInfoService {
	@Autowired
	private SellersRepository sellersRepo;
	@Autowired
private ItemsInfoRepository infoRepo;
	
	public Optional<ItemsInfo> addItem(ItemsInfo items, Integer sellersId) {
		
		return sellersRepo.findById(sellersId).map(sellersI ->{
				items.setSellers(sellersI);
				return infoRepo.save(items);
				
		}) ;
	}
	public List<ItemsInfo> getAllItems(Integer sellersId){
		return infoRepo.findBySellerId(sellersId);
	}
	public ItemsInfo modifyItem(ItemsInfo item, Integer itemId) {
		Optional<ItemsInfo> optionalItem = infoRepo.findById(itemId);
		if(optionalItem.isPresent()) {
			ItemsInfo updatedItem = optionalItem.get();
			updatedItem.setStock(item.getStock());
			updatedItem.setCategoriesId(item.getCategoriesId());
			updatedItem.setDescription(item.getDescription());
		
			updatedItem.setSubCategoriesId(item.getSubCategoriesId());
			updatedItem.setItemsName(item.getItemsName());
			updatedItem.setRemark(item.getRemark());
			
			return infoRepo.save(updatedItem);
		}
		
		return null;
	}
	
	public void removeItem(Integer sellersId, Integer itemsId) {
		infoRepo.deleteItemsInfoById(sellersId,itemsId);
	}
	
	public List<ItemsInfo> searchItem(SearchItems items) {
		System.out.println(items);
		return infoRepo.searchItem(items.getSearchString().toLowerCase());
	}
}
