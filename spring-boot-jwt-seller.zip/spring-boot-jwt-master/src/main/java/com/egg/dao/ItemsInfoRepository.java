package com.egg.dao;

import java.util.List;

import javax.transaction.Transactional;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.egg.model.ItemsInfo;




@Repository
public interface ItemsInfoRepository extends JpaRepository<ItemsInfo, Integer>{

	
	@Query(value="SELECT * FROM items_info WHERE items_info.sellers_id= :sellers_id",nativeQuery=true)
	List<ItemsInfo> findBySellerId(@Param(value="sellers_id") Integer sellers_id);
	
	@Transactional
	@Modifying
	@Query(value="DELETE FROM items_info WHERE items_info.sellers_id = :sellersId AND items_info.items_id = :itemsId",nativeQuery=true)
	public void deleteItemsInfoById(@Param("sellersId") Integer sellersId,@Param("itemsId") Integer itemsId);
	
	@Query(value = "FROM ItemsInfo WHERE lower(itemsName) LIKE %:itemsName%")
	public List<ItemsInfo> searchItem(@Param("itemsName") String items); 
	


}
