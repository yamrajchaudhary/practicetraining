package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.egg.model.Sellers;





@Repository
public interface SellersRepository extends JpaRepository<Sellers, Integer>  {

	Sellers findByusername(String username);

}
